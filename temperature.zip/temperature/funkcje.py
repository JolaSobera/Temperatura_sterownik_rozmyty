#### Funkcje pomocnicze
import dzialania_rozmyte
import reguly
def wyznacz_odpalone_regul_z_danej_bazy(baza, wejscie, nazwa_zbiorow , wybrane_dzialanie):
  """
  Funkcja wyznacza odpalone reguły z danej bazy.
  """
  lista_wynik = []
  for zbior in baza:
    lista = wejscie.dzialanie(zbior, nazwa_zbiorow, wybrane_dzialanie)[1]
    if any(lista):
      niezerowe = [el for el in lista if el>0]
      #print(zbior, max(niezerowe), niezerowe)
      lista_wynik.append((zbior,  max(niezerowe)))
  return lista_wynik

def odpalone_reguly_z_klima(lista_in, lista_out, agregacja = dzialania_rozmyte.T_minimum):
  """
  Funkcja zwraca nazwy odpalonych reguł wraz ze stopniem odpalenia.
  Po odkomentowaniu print widać z jakich przesłanek powstała reguła.
  W opisie odpowiada to -> liczymy  t=min(TZ−0,TW−1)  (agregacja)
  """
  wyniki = []
  for arg_out in lista_out:
    for arg_in in lista_in:
      wynik_agregacji = agregacja(arg_out[1], arg_in[1])###to jest t w powyższym wzorze
      #print(((arg_out, arg_in, (regulyu.reguly[arg_out[0]][arg_in[0]], wynik_agregacji))))
      wyniki.append((reguly.reguly[arg_out[0]][arg_in[0]], wynik_agregacji))
  return wyniki

def wynik_implikacji(klima, nazwy_odpalonych_regul_z_klima, dzialanie_implikacja = dzialania_rozmyte.T_minimum ):
  """Funkcja zwraca wynik J(t,K)  (J- dowolna implikacja lub funkcja minimum)
     t jest to liczba wyznaczona jako stopień odpalenia,
     K jest to nazwa zbioru rozmytego z przestrzeni klima.
     Wynikiem jest obciety zbiór klima - dokładnie tak wygląda to w przypadku minimum  w przypadku implikacji wygląda to inaczej zgodnie z wynikem wnioskowania
  """
  nazwy_wynikow_implikacji = []
  for el in nazwy_odpalonych_regul_z_klima:
    wynik = klima.implikacja_podglad(el[1], el[0], dzialanie_implikacja)
    #print(wynik)
    nazwy_wynikow_implikacji.append(wynik[0])
  return nazwy_wynikow_implikacji

def suma_wektorow(wektor1, wektor2):
    '''
    Funkcja zwraca sumę dwóch wektorów.
    '''
    #print(wektor1, wektor2)
    s = wektor1[::]
    #print(f"funkcja suma {s}")
    #print(wektor2)
    for i in range(len(wektor1)):
      s[i] += wektor2[i]
    return s

def wyznacz_sume_elementow_z_listy_po_implikacji(klima, lista_wynikow_po_implikacji):
  """
  Funkcja wyznacza sumę elementów listy zawierającej wyniki działania implikacji.
  Zwraca jeden zbiór rozmyty.
  Tę funkcję można ulepszyć teraz nie jest optymalna.
  """
  wynik_suma = klima.get_zbior(lista_wynikow_po_implikacji[0])
  for i  in range(1,len(lista_wynikow_po_implikacji)):
    wynik_suma = suma_wektorow(wynik_suma, klima.get_zbior(lista_wynikow_po_implikacji[i]))
  return wynik_suma

def usun_zbiory_z_przestrzeni(przestrzen, nazwa = 'I'):
  "Funkcja usuwa zbiory rozpoczynające się podaną nazwą z podanej przestrzeni"
  lista_do_usuniecia = []
  for el in przestrzen.get_zbiory().keys():
    if el.startswith(nazwa):
      lista_do_usuniecia.append(el)
  for el in lista_do_usuniecia:
      przestrzen.usun_zbior_rozmyty(el)
  return "Usunięto zbiory"

def my_round(arg, dokladnosc=0):
    """Funkcja zokrągla podany argument do podanej w drugim argumencie liczby cyfr."""
    if dokladnosc ==0 :
        return int(arg)
    if not isinstance(arg, float):
        raise Exception("Bład typu")
    else:
        lista = str(arg).split(".")
        calosci = int(lista[0])
        cyfry = lista[1]
        if len(cyfry) <= dokladnosc:
             dokladnosc = len(cyfry)
             cyfry = int(cyfry)
        else:
            cyfry = lista[1][:dokladnosc]
            cyfry = int(cyfry)
            if int(lista[1][dokladnosc])>=5:
                cyfry = cyfry+1
        cyfry = cyfry*10**(-1*dokladnosc)
        return calosci+cyfry


