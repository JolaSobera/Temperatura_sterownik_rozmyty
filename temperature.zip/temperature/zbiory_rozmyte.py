import dzialania_rozmyte
from plik_klasy import ZbiorRozmyty
import funkcje

def tworz_przestrzenie(temp_optymalna_in = 23, temp_optymalna_out = 23, tolerancja = 6, dokladnosc = 0.1):
  """Funkcja tworzy przestrzenie IN, OUT i KLIMA i dodaje do nich zbiory rozmyte."""

  ###co to znaczy optymaalna [temp_opymalna-toloerancja, temp_optymalna+tolerancja]
  try:
    ile_zbiorów = 7 ### ile zbiorw ma opisywać temperatury
    x_max = 49
    x_min = -19

    z_out = ZbiorRozmyty(x_min-1, x_max+1, dokladnosc, "temperatura_zewnetrzna")
    z_in = ZbiorRozmyty(x_min-1, x_max+1, dokladnosc, "temperatura_wewnetrzna")
    klima = ZbiorRozmyty(-6, 6, dokladnosc, "klimatyzator")

    ### OUT
    z_out.nowy_zbior_rozmyty(temp_optymalna_out-tolerancja, temp_optymalna_out, temp_optymalna_out, temp_optymalna_out+tolerancja, "TZ-0")
    krok = (x_max - (temp_optymalna_out + tolerancja))/2
    sr_prawy_out = temp_optymalna_out + tolerancja + krok
    z_out.nowy_zbior_rozmyty(temp_optymalna_out, temp_optymalna_out+ tolerancja, temp_optymalna_out+tolerancja, sr_prawy_out, "TZ+1")
    z_out.nowy_zbior_rozmyty(temp_optymalna_out+ tolerancja, sr_prawy_out, sr_prawy_out, x_max, "TZ+2")
    z_out.nowy_zbior_rozmyty(sr_prawy_out, x_max, x_max, x_max, "TZ+3")
    krok = ((temp_optymalna_out - tolerancja) - x_min)/2
    sr_lewy_out = temp_optymalna_out - tolerancja - krok
    z_out.nowy_zbior_rozmyty(x_min,  x_min, x_min, sr_lewy_out, "TZ-3")
    z_out.nowy_zbior_rozmyty(x_min, sr_lewy_out, sr_lewy_out, temp_optymalna_out-tolerancja, "TZ-2")
    z_out.nowy_zbior_rozmyty(sr_lewy_out, temp_optymalna_out - tolerancja, temp_optymalna_out-tolerancja, temp_optymalna_out, "TZ-1")

    ###IN
    krok = (x_max - (temp_optymalna_in + tolerancja))/2
    sr_prawy_in = temp_optymalna_in + tolerancja + krok
    krok = ((temp_optymalna_in - tolerancja) - x_min)/2
    sr_lewy_in = temp_optymalna_in - tolerancja - krok
    z_in.nowy_zbior_rozmyty(x_min,  x_min, x_min, sr_lewy_in, "TW-3")
    z_in.nowy_zbior_rozmyty(x_min, sr_lewy_in, sr_lewy_in, temp_optymalna_in-tolerancja, "TW-2")
    z_in.nowy_zbior_rozmyty(sr_lewy_in, temp_optymalna_in - tolerancja, temp_optymalna_in-tolerancja, temp_optymalna_in, "TW-1")
    z_in.nowy_zbior_rozmyty(temp_optymalna_in-tolerancja, temp_optymalna_in, temp_optymalna_in, temp_optymalna_in+tolerancja, "TW-0")
    z_in.nowy_zbior_rozmyty(temp_optymalna_in, temp_optymalna_in+ tolerancja, temp_optymalna_in+tolerancja, sr_prawy_in, "TW+1")
    z_in.nowy_zbior_rozmyty(temp_optymalna_in+ tolerancja, sr_prawy_in, sr_prawy_in, x_max, "TW+2")
    z_in.nowy_zbior_rozmyty(sr_prawy_in, x_max, x_max, x_max, "TW+3")

    #### Klima
    klima.nowy_zbior_rozmyty(-5, -5, -5, -4, "K-5")
    klima.nowy_zbior_rozmyty(-5, -4, -4, -3, "K-4")
    klima.nowy_zbior_rozmyty(-4, -3, -3, -2, "K-3")
    klima.nowy_zbior_rozmyty(-3, -2, -2, -1, "K-2")
    klima.nowy_zbior_rozmyty(-2, -1, -1, 0, "K-1")
    klima.nowy_zbior_rozmyty(-1, 0, 0, 1, "K-0")
    klima.nowy_zbior_rozmyty(0, 1, 1, 2, "K+1")
    klima.nowy_zbior_rozmyty(1, 2, 2, 3, "K+2")
    klima.nowy_zbior_rozmyty(2, 3, 3, 4, "K+3")
    klima.nowy_zbior_rozmyty(3, 4, 4, 5, "K+4")
    klima.nowy_zbior_rozmyty(4, 5, 5, 5, "K+5")
    return z_in, z_out, klima
  except Exception as e:
    raise e

def sterownik(z_in, z_out, klima, odczyt_in, odczyt_out, dzialanie_implikacja = dzialania_rozmyte.T_minimum, agregacja = dzialania_rozmyte.T_minimum , blad = 1):
  """Funkcja wykonuje pracę sterowniak rozmytego zwraca wynik w postaci krotki, pierwszy el jest opisowy, drugi to ustawienir klimatyzatora."""
  ### Rozmywamy
  ### lista zbiorów rozmytych z przestrzeni przed dadaniem odczytu
  try:
    baza_out = list(z_out.get_zbiory().keys() )
    baza_in = list(z_in.get_zbiory().keys())
    baza_klima = list(klima.get_zbiory().keys())
    #print("z_in ", z_in)
    #print("z_out ", z_out)
    #print("klima ", klima)
    #print("Baza_in ", baza_in)
    #print("Baza_out ", baza_out)
    #print("Baza_klima ", baza_klima)
    t_out = z_out.nowy_zbior_rozmyty(odczyt_out-blad, odczyt_out, odczyt_out, odczyt_out+blad, "TZ",1)
    lista_out = funkcje.wyznacz_odpalone_regul_z_danej_bazy(baza_out, z_out, "TZ", dzialania_rozmyte.T_produktowa)
    #print("Lista_out", lista_out)
    t_in = z_in.nowy_zbior_rozmyty(odczyt_in-blad, odczyt_in, odczyt_in, odczyt_in+blad, "IN")
    lista_in = funkcje.wyznacz_odpalone_regul_z_danej_bazy(baza_in, z_in, "IN", dzialania_rozmyte.T_minimum )
    #print("Lista_in", lista_in)
    #### Pobieramy odpalnie reguły
    nazwy_odpalonych_regul_z_klima = funkcje.odpalone_reguly_z_klima(lista_in, lista_out, agregacja = dzialania_rozmyte.T_minimum )
    #print("Lista_odpalonych z klima")
    #for el in nazwy_odpalonych_regul_z_klima:
     # print(el)
    lista_wynikow_po_implikacji =  funkcje.wynik_implikacji(klima, nazwy_odpalonych_regul_z_klima, dzialanie_implikacja = dzialania_rozmyte.T_minimum )
    #print("Lista wyników po implikacji", lista_wynikow_po_implikacji)
    suma_el_po_implikacji = funkcje.wyznacz_sume_elementow_z_listy_po_implikacji(klima, lista_wynikow_po_implikacji)
    ###Wyostrzamy
    #print("Wyostrzamy")
    ustawienie_klimatyzatora = klima.wyostrzenie(suma_el_po_implikacji)
    wynik_opis = "Dla danych wejściowych temperatury wewnątrz pomieszczenia: "+ str(odczyt_in)
    wynik_opis += "\nDla danych wejściowych temperatury na zewnątrz pomieszczenia: " +str(odczyt_out)
    wynik_opis += "\nustawienie klimatyzatora w pozycji " + str(ustawienie_klimatyzatora)
    return wynik_opis, ustawienie_klimatyzatora
  except Exception as e:
    return e
  finally:
    ##Sprzątamy
    z_in.usun_zbior_rozmyty("IN")
    z_out.usun_zbior_rozmyty("TZ")
    funkcje.usun_zbiory_z_przestrzeni(klima, "I")
