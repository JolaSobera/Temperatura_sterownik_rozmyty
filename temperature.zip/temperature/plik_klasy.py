import dzialania_rozmyte
class ZbiorRozmyty:
  '''
    Klasa tworzy przestrzeń i zawiera słownik zbiorów rozmytych.

    Argumenty:
      xp - początek przedziału przestrzeni X
      xk - koniec przedziału przestrzeni X
      step - krok - jak gęsto będzie podzielona przestrzeń X
      nazwa - nazwa rodziny zbiorów rozmytych

    Atrybuty:
      przestrzen - lista - przestrzeń X przedstawiona w sposób dyskretny [xp, xp+step, ... xk]
      zbiory - słownik zawierający zbiory rozmyte określone na przestrzeni X
      nazwa - nazwa rodziny zbiorów rozmytych
  '''
  def __init__(self, xp, xk, step, nazwa):
      self.przestrzen = []
      i = 0
      while xp+i <= xk:
          self.przestrzen.append(round(xp+i,2))
          i += step

      self.zbiory = {}
      self.nazwa = nazwa

  def get_przestrzen(self):
    "Zwraca listę - wartości przestrzeni"
    return self.przestrzen
  def get_zbiory(self):
    "Zwraca słownik wszystkich zbiorów rozmytych dołączonych do przestrzeni"
    return self.zbiory
  def get_zbior(self, nazwa):
    "Zwraca wartosci  zbioru rozmytego o podanej nazwie z przestrzeni"
    return self.zbiory[nazwa]

  def get_nazwa(self):
    return self.nazwa

  def nowy_zbior_rozmyty(self, a0, a1, b1, b0, nazwa, max_wysokosc = 1, dodaj_do_slownika = True):
        '''
        Funkcja dodaje nowy zbiór rozmyty do przestrzeni lub zwraca listę jego wartośći
        '''
        zbior = (a0, a1, b1, b0)
        if dodaj_do_slownika:
          self.zbiory[nazwa] =  self.zbior_rozmyty_wartosc(a0, a1, b1, b0, max_wysokosc)##(zbior, max_wysokosc)
        else:
          return self.zbior_rozmyty_wartosc(a0, a1, b1, b0, max_wysokosc)
  #def nowy_obciety(self, nazwa, poziom):
   #   self.zbiory[nazwa+str(poziom)] = [min(i, poziom) for i in self.get_zbior(nazwa) ]

  def usun_zbior_rozmyty(self, nazwa):
    """Usuwa ze słownika zbiorów rozmytych element o podanej nazwie."""
    if nazwa not in self.zbiory.keys():
      return "Zbiór nie uzunęty - nie ma go w przestrzeni"
    del(self.zbiory[nazwa])
    return "Usunięto zbiór "+ nazwa

  def zbior_rozmyty_wartosc(self, a0, a1, b1, b0, max_wysokosc = 1 ):
        '''
        Funkcja oblicza wartosc funkcji przynależności zbioru rozmytego dla zadanego punktu.
        Returns:
          Listę wartości.
        '''
        linia_a = ZbiorRozmyty.funkcja_liniowa([a0, 0], [a1, max_wysokosc])##współczynniki a, b
        linia_b = ZbiorRozmyty.funkcja_liniowa([b1, max_wysokosc], [b0, 0])
       ## lista = [0] * len(self.get_przestrzen())
        lista = []
       #print(f"Przestrzeń {len(self.get_przestrzen())}")
        krok = round(self.przestrzen[1] - self.przestrzen[0],2)
        pocz = self.przestrzen[0]
        koniec = self.przestrzen[-1]
        #print(pocz, koniec, krok)
        if a0 == a1:## a0=a1=b1 trapez ----____
          #print("## a0=a1=b1 trapez ----____")
          while pocz <= b1:
            lista.append(1)
            pocz = round(pocz+krok, 2)
          while pocz <= b0:
            lista.append(round(linia_b[0]*pocz + linia_b[1],2))
            pocz = round(pocz+krok, 2)
          while pocz <= koniec:
            lista.append(0)
            pocz = round(pocz+krok, 2)
        elif b0 == b1:##  a1 = b1 = b0 trapez  ____----
          #print("a1 = b1 = b0 trapez  ____----")
          while pocz <= a0:
            lista.append(0)
            pocz = round(pocz+krok, 2)
          while pocz <= a1:
            lista.append(round(linia_a[0]*pocz + linia_a[1],2))
            pocz = round(pocz+krok, 2)
          while pocz <= koniec:
            lista.append(1)
            pocz = round(pocz+krok, 2)
        elif a1 == b1: ## trójkątny a1=b1
          #print("trójkatny")
          while pocz <= a0:
            lista.append(0)
            pocz = round(pocz+krok, 2)
          while pocz <= a1:
            lista.append(round(linia_a[0]*pocz + linia_a[1],2))
            pocz = round(pocz+krok, 2)
          ###jedna jedynka bo trójkątny
          lista.append(1)
          pocz = round(pocz+krok, 2)
          while pocz <= b0:
            lista.append(round(linia_b[0]*pocz + linia_b[1],2))
            pocz = round(pocz+krok, 2)
          while pocz <= koniec:
            lista.append(0)
            pocz = round(pocz+krok, 2)
        else: #trapez _____------_____
          print("trapez _____------_____")
          while pocz <= a0:
            lista.append(0)
            pocz = round(pocz+krok, 2)
          while pocz <= a1:
            lista.append(round(linia_a[0]*pocz + linia_a[1],2))
            pocz = round(pocz+krok, 2)
          while pocz <= b1:
            lista.append(max_wysokosc)
            pocz = round(pocz+krok, 2)
          while pocz <= b0:
            lista.append(round(linia_b[0]*pocz + linia_b[1],2))
            pocz = round(pocz+krok, 2)
          while pocz <= koniec:
            lista.append(0)
            pocz = round(pocz+krok, 2)
       # print(f"Lista = {len(lista)}")

        return lista

  def funkcja_liniowa(c, d):
        '''
        Funkcja służy do wyznaczana równania prostej przechodzącej przez dwa punkty c i d.

        Argumenty:
          c, d - krotki lub listy zawierające współrzędne punktów, przez które przechodzi prosta.

        Wynik:
          Funkcja zwraca krotkę zawierającą wartości współczynników funkcji liniowej ax + b przechodzącej przez
          punkty c i d gdy d[0] jest różne od c[0] lub wartość d[0] jeżeli prosta ma równanie x=d[0]
          tzn. jest prostopadła do osi OX.
        '''

        if d[0] - c[0] != 0:
          a = (d[1] - c[1]) / (d[0] - c[0])
          b = -a*c[0] + c[1]
          return (a, b)
        else:
          return d[0]

  def rysuj(self):
    "Funkcja rysuje wszystkie zbiory rozmyte dla zadanej przestrzeni."
    argumenty = self.get_przestrzen()
    for i in list(self.get_zbiory().keys()):
      wartosci = self.get_zbiory()[i]
      plt.plot(argumenty, wartosci)

  def rysuj_zbior(self, nazwa, odciete = 0, kolor = "green"):
    """Funkcja rysuje zbiór rozmyty o podaneje nazwie dla zadanej przestrzeni.
      Argument odcięt jest wykorzystywany w przypadku zbiorów z przestrzeni wyników.
    """

    argumenty = self.get_przestrzen()
    wartosci = self.get_zbior(nazwa)
    plt.plot(argumenty, wartosci, kolor)
    if odciete != 0:
      plt.plot(argumenty, [odciete for i in range(len(argumenty))], kolor)


  def dzialanie(self, set1, set2, dzialanie = dzialania_rozmyte.T_minimum, plot = False):
    """Funkcja wyznacza iloczyn dwóch zbiorów rozmytych z wykorzystaniem wybranej T normy
    Returns
      (tuple): nazwa, wartość iloczynu
    """
    wartosci_set1 = self.get_zbior(set1)
    wartosci_set2 = self.get_zbior(set2)
    wartosc_suma = [round(dzialanie(wartosci_set1[i], wartosci_set2[i]),2) for i in range(0,len(wartosci_set2))]
    #print(wartosci_set1)
    #print(wartosci_set2)
    nazwa = "iloczyn_"+set1+"_"+set2
    return (nazwa,wartosc_suma)

  def implikacja_podglad(self, wartosc, set1, implikacja = dzialania_rozmyte.I_Fodor, plot = False):
      """Funkcja wyznacza wartość implikacji .
      Returns:
        (tuple): nazwa, lista zawierająca wartości punkt po punkcie J(K,wartosc)"""
      wartosci_set1 = self.get_zbior(set1)
      wartosc_implikacji = [round(implikacja(wartosc, wartosci_set1[i]),2) for i in range(0,len(wartosci_set1))]
      nazwa = "I_"+set1+"_" + str(wartosc)
      self.zbiory[nazwa] = wartosc_implikacji
      return (nazwa, wartosc_implikacji)

  def wyostrzenie(self, wektor):
        '''
        funkcja zwraca wyostrzona wartosc zwracana przez sterownik metoda środka ciężkości
        '''
        wartosci_zbior = wektor #self.get_zbior(nazwa) ##y
        wartosci_przestrzen = self.get_przestrzen() ### x iksy
        krok = wartosci_przestrzen[1] - wartosci_przestrzen[0]
        start = wartosci_przestrzen[0]
        licznik = 0
        mianownik = 0
        for i in range(len(wartosci_zbior)):
            wartosc =  wartosci_zbior[i] * (start + i* krok)
            licznik = licznik + wartosc
            mianownik = mianownik +  wartosci_zbior[i]
        srednia_wazona = licznik/mianownik
        return round(srednia_wazona,2)