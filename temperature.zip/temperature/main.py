#!/usr/bin/env pybricks-micropython
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile

from pybricks.nxtdevices import TemperatureSensor

import math
import dzialania_rozmyte
from reguly import reguly
from plik_klasy import ZbiorRozmyty
import zbiory_rozmyte
import funkcje


# This program requires LEGO EV3 MicroPython v2.0 or higher.
# Click "Open user guide" on the EV3 extension tab for more information.


# Create your objects here.

ev3 = EV3Brick()
_out = TemperatureSensor(Port.S1)
_in = TemperatureSensor(Port.S2)
_motor = Motor(Port.A)

temp_optymalna_in = 23
temp_optymalna_out  = 25
dokladnosc = 0.1
tolerancja = 6 ## co to znaczy optymaalna [temp_opymalna-toloerancja, temp_optymalna+tolerancja]
ile_zbiorów = 7 ### ile zbiorw ma opisywać temperatury
try:
   z_in, z_out, klima = zbiory_rozmyte.tworz_przestrzenie(temp_optymalna_in=23, temp_optymalna_out=23, tolerancja=6, dokladnosc=0.1)
   ev3.screen.print("Przestrzenie uworzone")
except Exception as e:
      print(e)
wentylator = "OFF"
ev3.speaker.beep()
while True:
   odczyt_in = _in.temperature()
   odczyt_out = _out.temperature()
   ###wynik = zbiory_rozmyte.sterownik(odczyt_in, odczyt_out, dzialanie_implikacja = dzialania_rozmyte.T_minimum)
   wynik = zbiory_rozmyte.sterownik(z_in = z_in, z_out = z_out, klima = klima, odczyt_in  = odczyt_in, odczyt_out = odczyt_out, dzialanie_implikacja = dzialania_rozmyte.T_minimum)
   print(wynik[0])  
   ev3.screen.print("TEMP out ", odczyt_out)
   ev3.screen.print("TEMP in ", odczyt_in)
   ev3.screen.print("Ustawienie", wynik[1])
   if wynik[1]>0:   
      ev3.light.on(Color.RED)
      _motor.stop()
      wentylator = "OFF"
   else:
      ev3.light.on(Color.GREEN)
      v = wynik[1] * -100
      _motor.run(v)
      # Play another beep sound.
      if wentylator == "OFF":
         ##print("iff")
         ev3.speaker.beep()
         wentylator = "ON"
   wait(5000)
# Write your program here.
ev3.speaker.beep()
